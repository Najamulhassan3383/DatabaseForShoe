﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

    public class conString{
        public static String connectionString = "Data Source=DESKTOP-9GQ5JFD\\SQLEXPRESS;Initial Catalog=ShoeStore2;Integrated Security=True";

    }
}
